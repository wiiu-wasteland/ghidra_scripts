#pragma once
#include <common/log.h>

namespace ios::net::internal
{

extern Logger netLog;

} // namespace ios::net::internal
