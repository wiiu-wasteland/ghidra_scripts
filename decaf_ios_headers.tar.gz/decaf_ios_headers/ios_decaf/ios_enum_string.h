#pragma once
#include <cstdint>
#include <string>
#include "ios_enum.h"

#undef IOS_ENUM_H
#include <common/enum_string_declare.inl>
#include "ios_enum.h"
#include <common/enum_end.inl>
