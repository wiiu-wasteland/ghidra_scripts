#pragma once

namespace nn
{

void
initialiseProcess();

void
uninitialiseProcess();

} // namespace nn
