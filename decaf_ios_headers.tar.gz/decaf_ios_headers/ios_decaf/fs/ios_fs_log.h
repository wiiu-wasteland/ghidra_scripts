#pragma once
#include <common/log.h>

namespace ios::fs::internal
{

extern Logger fsLog;

} // namespace ios::fs::internal
