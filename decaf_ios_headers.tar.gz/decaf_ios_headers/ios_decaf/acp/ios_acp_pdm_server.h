#pragma once
#include "ios/ios_enum.h"

namespace ios::acp::internal
{

Error
startPdmServer();

void
initialiseStaticPdmServerData();

} // namespace ios::acp::internal
