#pragma once
#include <common/log.h>

namespace ios::acp::internal
{

extern Logger acpLog;

} // namespace ios::acp::internal
