#pragma once
#include "ios/ios_enum.h"

namespace ios::acp::internal
{

Error
startNnsm();

void
initialiseStaticNnsmData();

} // namespace ios::namespace ios::acp::internal
