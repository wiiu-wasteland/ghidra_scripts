#pragma once
#include "ios_kernel_enum.h"
#include "ios_kernel_threadqueue.h"
#include "ios/ios_enum.h"

#include <common/cbool.h>
#include <common/structsize.h>
#include <libcpu/be2_struct.h>

#define MaxNumMessageQueues 750

struct Thread;

typedef int32_t MessageQueueId;
typedef uint32_t Message;

struct MessageQueue
{
   ThreadQueue receiveQueue;
   ThreadQueue sendQueue;
   u32 used;
   u32 first;
   u32 size;
   Message * messages;
   s32 uid;
   u8 pid;
   MessageQueueFlags flags;
   u16 unk0x1E;
};

Error
IOS_CreateMessageQueue(Message * messageBuffer,
                       uint32_t numMessages);

Error
IOS_DestroyMessageQueue(MessageQueueId id);

Error
IOS_SendMessage(MessageQueueId id,
                Message message,
                MessageFlags flags);

Error
IOS_JamMessage(MessageQueueId id,
               Message message,
               MessageFlags flags);

Error
IOS_ReceiveMessage(MessageQueueId id,
                   Message * message,
                   MessageFlags flags);
