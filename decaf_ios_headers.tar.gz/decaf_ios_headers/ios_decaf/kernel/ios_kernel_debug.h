#pragma once
#include "ios_kernel_enum.h"
#include "ios/ios_enum.h"

Error
IOS_SetSecurityLevel(SecurityLevel level);

SecurityLevel
IOS_GetSecurityLevel();
