#pragma once
#include <common/structsize.h>
#include <libcpu/be2_struct.h>

struct Thread;

struct ThreadQueue
{
   //! Linked list on thread->threadQueueNext.
   Thread * first;
};
