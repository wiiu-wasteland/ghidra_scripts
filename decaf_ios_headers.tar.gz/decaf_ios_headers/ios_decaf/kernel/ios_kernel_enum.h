#pragma once

enum DeviceId {
   Timer = 0,
   NandInterfaceAHBALL = 1,
   AesEngineAHBALL = 2,
   Sha1EngineAHBALL = 3,
   UsbEhci = 4,
   UsbOhci0 = 5,
   UsbOhci1 = 6,
   SdHostController = 7,
   Wireless80211 = 8,
   SysEvent = 9,
   SysProt = 10,
   PowerButton = 15,
   DriveInterface = 16,
   ExiRtc = 18,
   Sata = 26,
   IpcStarbuckCompat = 29,
   Unknown30 = 30,
   Unknown31 = 31,
   Unknown32 = 32,
   Unknown33 = 33,
   Drh = 34,
   Unknown35 = 35,
   Unknown36 = 36,
   Unknown37 = 37,
   AesEngineAHBLT = 38,
   Sha1EngineAHBLT = 39,
   Unknown40 = 40,
   Unknown41 = 41,
   Unknown42 = 42,
   I2CEspresso = 43,
   I2CStarbuck = 44,
   IpcStarbuckCore2 = 45,
   IpcStarbuckCore1 = 46,
   IpcStarbuckCore0 = 47,
};

enum HeapFlags {
   LocalProcessHeap = 1 << 0,
   CrossProcessHeap = 1 << 1,
};

enum HeapBlockState {
   Free = 0xBABE0000,
   Allocated = 0xBABE0001,
   InnerBlock = 0xBABE0002,
};

enum MessageFlags {
   None = 0,
   NonBlocking = 1,
};

enum MessageQueueFlags {
   None = 0,
   RegisteredEventHandler = 1,
};

enum OtpFieldIndex {
   WiiBoot1Sha1Hash = 0x1,
   WiiCommonKey = 0x5,

};

enum RootThreadCommand {
   Timer = 0x100,
   SysprotEvent = 0x101,
};

enum ResourceHandleState {
   Free = 0x00,
   Opening = 0x11,
   Open = 0x22,
   Closed = 0x33,
};

enum ResourcePermissionGroup {
   None = 0,
   BSP = 1,
   DK = 3,
   FS = 11,
   UHS = 12,
   MCP = 13,
   NIM = 14,
   ACT = 15,
   FPD = 16,
   BOSS = 17,
   ACP = 18,
   PDM = 19,
   AC = 20,
   NDM = 21,
   NSEC = 22,
   PAD = 1000,
   All = 0x7FFFFFFF,
};

enum SecurityLevel {
   Test = 10,
   Debug = 20,
   Normal = 30,
};

enum ThreadFlags {
   Detached = 1 << 0,
   AllocateTLS = 1 << 1,
};

enum ThreadState {
   Available = 0x00,
   Ready = 0x01,
   Running = 0x02,
   Stopped = 0x03,
   Waiting = 0x04,
   Dead = 0x05,
   Faulted = 0x06,
   Unknown = 0x07,
};

enum TimerState {
   Free = 0x00,
   Ready = 0x01,
   Running = 0x02,
   Triggered = 0x03,
   Stopped = 0x04,
};
