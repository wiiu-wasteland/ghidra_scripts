#pragma once
#include "ios_kernel_messagequeue.h"
#include "ios_kernel_resourcemanager.h"
#include "ios/ios_ipc.h"

Error
IOS_Open(char * device,
         OpenMode mode);

Error
IOS_OpenAsync(char * device,
              OpenMode mode,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Close(ResourceHandleId handle);

Error
IOS_CloseAsync(ResourceHandleId handle,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Read(ResourceHandleId handle,
         void * buffer,
         uint32_t length);

Error
IOS_ReadAsync(ResourceHandleId handle,
              void * buffer,
              uint32_t length,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Write(ResourceHandleId handle,
          void * buffer,
          uint32_t length);

Error
IOS_WriteAsync(ResourceHandleId handle,
               void * buffer,
               uint32_t length,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Seek(ResourceHandleId handle,
         uint32_t offset,
         uint32_t origin);

Error
IOS_SeekAsync(ResourceHandleId handle,
              uint32_t offset,
              uint32_t origin,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Ioctl(ResourceHandleId handle,
          uint32_t ioctlRequest,
          void * inputBuffer,
          uint32_t inputBufferLength,
          void * outputBuffer,
          uint32_t outputBufferLength);

Error
IOS_IoctlAsync(ResourceHandleId handle,
               uint32_t ioctlRequest,
               void * inputBuffer,
               uint32_t inputBufferLength,
               void * outputBuffer,
               uint32_t outputBufferLength,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Ioctlv(ResourceHandleId handle,
           uint32_t ioctlRequest,
           uint32_t numVecIn,
           uint32_t numVecOut,
           IoctlVec * vecs);

Error
IOS_IoctlvAsync(ResourceHandleId handle,
                uint32_t request,
                uint32_t numVecIn,
                uint32_t numVecOut,
                IoctlVec * vecs,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);

Error
IOS_Resume(ResourceHandleId handle,
           uint32_t unkArg0,
           uint32_t unkArg1);

Error
IOS_ResumeAsync(ResourceHandleId handle,
                uint32_t unkArg0,
                uint32_t unkArg1,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);

Error
IOS_Suspend(ResourceHandleId handle,
            uint32_t unkArg0,
            uint32_t unkArg1);

Error
IOS_SuspendAsync(ResourceHandleId handle,
                 uint32_t unkArg0,
                 uint32_t unkArg1,
                 MessageQueueId asyncNotifyQueue,
                 IpcRequest * asyncNotifyRequest);

Error
IOS_SvcMsg(ResourceHandleId handle,
           uint32_t command,
           uint32_t unkArg1,
           uint32_t unkArg2,
           uint32_t unkArg3);

Error
IOS_SvcMsgAsync(ResourceHandleId handle,
                uint32_t command,
                uint32_t unkArg1,
                uint32_t unkArg2,
                uint32_t unkArg3,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);
