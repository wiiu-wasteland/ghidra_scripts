#pragma once
#include "ios_kernel_enum.h"
#include "ios_kernel_messagequeue.h"

#include <chrono>
#include <common/bitfield.h>

Error
IOS_HandleEvent(DeviceId id,
                MessageQueueId queue,
                Message message);

Error
IOS_UnregisterEventHandler(DeviceId id);

Error
IOS_ClearAndEnable(DeviceId id);

Error
IOS_SetBspReady();
