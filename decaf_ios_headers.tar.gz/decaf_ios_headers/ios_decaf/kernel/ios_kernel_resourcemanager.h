#pragma once
#include "ios_kernel_enum.h"
#include "ios_kernel_messagequeue.h"
#include "ios/ios_enum.h"
#include "ios/ios_ipc.h"
#include <libcpu/be2_struct.h>
#include <common/structsize.h>

#define MaxNumResourceManagers 96
#define MaxNumResourceRequests 256

#define MaxNumResourceHandlesPerProcess 96
#define MaxNumResourceManagersPerProcess 32
#define MaxNumResourceRequestsPerProcess 32
#define MaxNumClientCapabilitiesPerProcess 20

typedef int32_t ResourceHandleId;
typedef int32_t FeatureId;
typedef uint64_t ClientCapabilityMask;

struct ResourceManager;
struct ResourceManagerList;

struct ResourceHandle;
struct ResourceHandleManager;

struct ResourceRequest;
struct ResourceRequestList;

#pragma pack(push, 1)

struct ResourceManager
{
   //! Name of the device this resource manager manages.
   char device[32];

   //! ID of the message queue associated with this resource.
   MessageQueueId queueId;

   //! Pointer to the resource handle manager for this resource manager.
   ResourceHandleManager * resourceHandleManager;

   //! Permission Group this resource belongs to, this matches values in cos.xml.
   ResourcePermissionGroup permissionGroup;

   //! Length of the string in this->device
   u16 deviceLen;

   //! Index of the first resource request for this resource in the global
   //! resource request list.
   s16 firstRequestIdx;

   //! Index of the last resource request for this resource in the global
   //! resource request list.
   s16 lastRequestIdx;

   //! Number of resource requests active for this resource.
   u16 numRequests;

   //! Number of resource handles active for this resource.
   u16 numHandles;

   //! Index of the next active resource manager.
   s16 nextResourceManagerIdx;

   //! Index of the previous active resource manager.
   s16 prevResourceManagerIdx;

   u16 unk0x3A;
   u16 unk0x3C;
   u16 unk0x3E;
};

struct ResourceManagerList
{
   //! Number of registered resource managers.
   u16 numRegistered;

   //! The highest number of registered resource managers at one time.
   u16 mostRegistered;

   //! Index of the first registered resource manager.
   s16 firstRegisteredIdx;

   //! Index of the last registered resource manager.
   s16 lastRegisteredIdx;

   //! Index of the first free resource manager.
   s16 firstFreeIdx;

   //! Index of the last free resource manager.
   s16 lastFreeIdx;

   //! List of resource managers.
   ResourceManager resourceManagers[MaxNumResourceManagers];
};

struct ResourceHandle
{
   //! The internal process handle returned by a successful IOS_Open request.
   s32 handle;

   //! The unique id of this resource handle.
   ResourceHandleId id;

   //! The resource manager this handle belongs to.
   ResourceManager * resourceManager;

   //! The state of this resource handle.
   ResourceHandleState state;
};

struct ClientCapability
{
   FeatureId featureId;
   ClientCapabilityMask mask;
};

/**
 * A per process structure to manage resource handles.
 */
struct ResourceHandleManager
{
   //! Title ID this resource handle manager belongs to.
   TitleId titleId;

   //! Group ID this resource handle manager belongs to.
   GroupId groupId;

   //! Process this resource handle manager belongs to.
   ProcessId processId;

   //! Number of current resource handles.
   u32 numResourceHandles;

   //! Highest number of resource handles at one time.
   u32 mostResourceHandles;

   //! Maximum number of resource handles, aka size of handles array.
   u32 maxResourceHandles;

   //! List of resource handles.
   ResourceHandle handles[MaxNumResourceHandlesPerProcess];

   //! Number of resource requests.
   u32 numResourceRequests;

   //! Highest number of resource requests at once.
   u32 mostResourceRequests;

   //! Number of times registerIpcRequest failed due to max number of resource requests.
   u32 failedRegisterMaxResourceRequests;

   //! Maxmimum allowed number of resource requests per process.
   u32 maxResourceRequests;

   //! Client Capabilities
   ClientCapability clientCapabilities[MaxNumClientCapabilitiesPerProcess];

   //! Number of resource managers for this process.
   u32 numResourceManagers;

   //! Maximum allowed number of resource managers for this process.
   u32 maxResourceManagers;

   //! Number of times IOS_ResourceReply failed
   u32 failedResourceReplies;
};

struct ResourceRequest
{
   //! Data store for the actual request.
   IpcRequest requestData;

   //! Message queue this resource request came from.
   MessageQueue * messageQueue;

   //! Message queue id, why store this and message queue, who knows..?
   MessageQueueId messageQueueId;

   //! Pointer to the IpcRequest that this resource request originated from.
   IpcRequest * ipcRequest;

   //! Pointer to the resource handle manager for this request.
   ResourceHandleManager * resourceHandleManager;

   //! Pointer to the resource manager for this request.
   ResourceManager * resourceManager;

   //! ID of the resource handle associated with this request.
   ResourceHandleId resourceHandleId;

   //! Index of the next resource request, used for either free or registered
   //! list in ResourceRequestList.
   s16 nextIdx;

   //! Index of the previous resource request, used for either free or registered
   //! list in ResourceRequestList.
   s16 prevIdx;

   //! Buffer to copy the device name to for IOS_Open calls.
   char openNameBuffer[32];

   char unknown[0x40];
};

/**
 * Storage for all resource requests.
 */
struct ResourceRequestList
{
   //! Number of registered resource requests.
   u16 numRegistered;

   //! Highest number of registered resource requests.
   u16 mostRegistered;

   u16 unk0x04;

   //! Index of first free element in resourceRequests.
   s16 firstFreeIdx;

   //! Index of last free element in resourceRequests.
   s16 lastFreeIdx;

   u16 unk0x0A;

   //! Resource Request storage.
   ResourceRequest resourceRequests[MaxNumResourceRequests];
};

#pragma pack(pop)

Error
IOS_SetResourceManagerRegistrationDisabled(bool enable);

Error
IOS_RegisterResourceManager(char * device,
                            MessageQueueId queue);

Error
IOS_AssociateResourceManager(char * device,
                             ResourcePermissionGroup group);

Error
IOS_ResourceReply(ResourceRequest * request,
                  Error reply);

Error
IOS_SetClientCapabilities(ProcessId pid,
                          FeatureId featureId,
                          uint64_t * mask);

Error
IOS_SetProcessTitle(ProcessId process,
                    TitleId title,
                    GroupId group);

