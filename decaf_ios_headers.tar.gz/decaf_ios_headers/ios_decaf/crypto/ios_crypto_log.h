#pragma once
#include <common/log.h>

namespace ios::crypto::internal
{

extern Logger cryptoLog;

} // namespace ios::crypto::internal
