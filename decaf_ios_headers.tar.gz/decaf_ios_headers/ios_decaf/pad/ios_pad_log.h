#pragma once
#include <common/log.h>

namespace ios::pad::internal
{

extern Logger padLog;

} // namespace ios::pad::internal
