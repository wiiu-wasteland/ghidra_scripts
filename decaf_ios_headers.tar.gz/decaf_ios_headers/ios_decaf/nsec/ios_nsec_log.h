#pragma once
#include <common/log.h>

namespace ios::nsec::internal
{

extern Logger nsecLog;

} // namespace ios::nsec::internal
