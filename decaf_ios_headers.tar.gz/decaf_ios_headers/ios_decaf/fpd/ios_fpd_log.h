#pragma once
#include <common/log.h>

namespace ios::fpd::internal
{

extern Logger fpdLog;

} // namespace ios::fpd::internal
