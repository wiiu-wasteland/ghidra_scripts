#pragma once
#include <common/log.h>

namespace ios::nim::internal
{

extern Logger nimLog;

} // namespace ios::nim::internal
