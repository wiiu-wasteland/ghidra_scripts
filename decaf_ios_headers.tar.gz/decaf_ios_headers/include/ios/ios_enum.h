#pragma once

enum CoreInterruptFlags {
   Shutdown = 1 << 0,
   Scheduler = 1 << 1,
};

enum InterruptFlags {
   Ahb = 1 << 0,
};

enum Command {
   Invalid = 0,
   Open = 1,
   Close = 2,
   Read = 3,
   Write = 4,
   Seek = 5,
   Ioctl = 6,
   Ioctlv = 7,
   Reply = 8,
   IpcMsg0 = 9,
   IpcMsg1 = 10,
   IpcMsg2 = 11,
   Suspend = 12,
   Resume = 13,
   SvcMsg = 14,
};

enum CpuId {
   ARM = 0,
   PPC0 = 1,
   PPC1 = 2,
   PPC2 = 3,
};

enum ErrorCategory {
   Kernel = 0,
   FSA = 3,
   MCP = 4,
   Unknown7 = 7,
   Unknown8 = 8,
   Socket = 10,
   ODM = 14,
   Unknown15 = 15,
   Unknown19 = 19,
   Unknown30 = 30,
   Unknown45 = 45,
};

enum Error {
   IOS_ERROR_OK = 0,
   IOS_ERROR_ACCESS = -1,
   IOS_ERROR_EXISTS = -2,
   IOS_ERROR_INTR = -3,
   IOS_ERROR_INVALID = -4,
   IOS_ERROR_MAX = -5,
   IOS_ERROR_NO_EXISTS = -6,
   IOS_ERROR_Q_EMPTY = -7,
   IOS_ERROR_Q_FULL = -8,
   IOS_ERROR_UNKNOWN = -9,
   IOS_ERROR_NOT_READY = -10,
   IOS_ERROR_ECC = -11,
   IOS_ERROR_ECC_CRIT = -12,
   IOS_ERROR_BAD_BLOCK = -13,
   IOS_ERROR_INVALID_OBJTYPE = -14,
   IOS_ERROR_INVALID_RNG = -15,
   IOS_ERROR_INVALID_FLAG = -16,
   IOS_ERROR_INVALID_FORMAT = -17,
   IOS_ERROR_INVALID_VERSION = -18,
   IOS_ERROR_INVALID_SIGNER = -19,
   IOS_ERROR_FAIL_CHECKVALUE = -20,
   IOS_ERROR_FAIL_INTERNAL = -21,
   IOS_ERROR_FAIL_ALLOC = -22,
   IOS_ERROR_INVALID_SIZE = -23,
   IOS_ERROR_NO_LINK = -24,
   IOS_ERROR_AN_FAILED = -25,
   IOS_ERROR_MAX_SEM_COUNT = -26,
   IOS_ERROR_SEM_UNAVAILABLE = -27,
   IOS_ERROR_INVALID_HANDLE = -28,
   IOS_ERROR_INVALID_ARG = -29,
   IOS_ERROR_NO_RESOURCE = -30,
   IOS_ERROR_BUSY = -31,
   IOS_ERROR_TIMEOUT = -32,
   IOS_ERROR_ALIGNMENT = -33,
   IOS_ERROR_BSP = -34,
   IOS_ERROR_DATA_PENDING = -35,
   IOS_ERROR_EXPIRED = -36,
   IOS_ERROR_NO_READ_ACCESS = -37,
   IOS_ERROR_NO_WRITE_ACCESS = -38,
   IOS_ERROR_NO_READ_WRITE_ACCESS = -39,
   IOS_ERROR_CLIENT_TXN_LIMIT = -40,
   IOS_ERROR_STALE_HANDLE = -41,
   IOS_ERROR_UNKNOWN_VALUE = -42,
   IOS_ERROR_MAX_KERNEL_ERROR = -0X400,
};

enum OpenMode {
   None = 0,
   Read = 1,
   Write = 2,
   ReadWrite = Read | Write,
};

enum ProcessId {
   Invalid = -4,
   KERNEL = 0,
   MCP = 1,
   BSP = 2,
   CRYPTO = 3,
   USB = 4,
   FS = 5,
   PAD = 6,
   NET = 7,
   ACP = 8,
   NSEC = 9,
   AUXIL = 10,
   NIM = 11,
   FPD = 12,
   TEST = 13,
   COSKERNEL = 14,
   COSROOT = 15,
   COS02 = 16,
   COS03 = 17,
   COSOVERLAY = 18,
   COSHBM = 19,
   COSERROR = 20,
   COSMASTER = 21,
   Max = 22,
};

enum SeekOrigin {
   Beg = 0,
   Cur = 1,
   End = 2,
};

enum SyscallId {
   CreateThread = 0x00,
   JoinThread = 0x01,
   CancelThread = 0x02,
   GetCurrentThreadId = 0x03,

   GetCurrentProcessId = 0x05,
   GetCurrentProcessName = 0x06,
   StartThread = 0x07,
   SuspendThread = 0x08,
   YieldThread = 0x09,
   GetThreadPriority = 0x0A,
   SetThreadPriority = 0x0B,
   CreateMessageQueue = 0x0C,
   DestroyMessageQueue = 0x0D,
   SendMessage = 0x0E,
   JamMessage = 0x0F,
   ReceiveMessage = 0x10,
   HandleEvent = 0x11,
   UnhandleEvent = 0x12,
   CreateTimer = 0x13,
   RestartTimer = 0x14,
   StopTimer = 0x15,
   DestroyTimer = 0x16,

   GetUpTimeStruct = 0x19,
   GetUpTime64 = 0x1A,

   GetAbsTimeCalendar = 0x1C,
   GetAbsTime64 = 0x1D,
   GetAbsTimeStruct = 0x1E,

   CreateLocalProcessHeap = 0x24,
   CreateCrossProcessHeap = 0x25,

   Alloc = 0x27,
   AllocAligned = 0x28,
   Free = 0x29,
   FreeAndZero = 0x2A,
   Realloc = 0x2B,
   RegisterResourceManager = 0x2C,

   Open = 0x33,
   Close = 0x34,
   Read = 0x35,
   Write = 0x36,
   Seek = 0x37,
   Ioctl = 0x38,
   Ioctlv = 0x39,
   OpenAsync = 0x3A,
   CloseAsync = 0x3B,
   ReadAsync = 0x3C,
   WriteAsync = 0x3D,
   SeekAsync = 0x3E,
   IoctlAsync = 0x3F,
   IoctlvAsync = 0x40,

   ResourceReply = 0x49,

   ClearAndEnable = 0x50,
   InvalidateDCache = 0x51,
};
