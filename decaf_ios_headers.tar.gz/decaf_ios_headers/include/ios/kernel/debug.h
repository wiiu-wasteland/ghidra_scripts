#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

Error
IOS_SetSecurityLevel(SecurityLevel level);

SecurityLevel
IOS_GetSecurityLevel();
