#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

Error
IOS_HandleEvent(DeviceId id,
                MessageQueueId queue,
                Message message);

Error
IOS_UnregisterEventHandler(DeviceId id);

Error
IOS_ClearAndEnable(DeviceId id);

Error
IOS_SetBspReady();
