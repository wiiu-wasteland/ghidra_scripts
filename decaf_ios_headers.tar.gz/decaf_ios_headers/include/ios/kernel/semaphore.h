#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

// Max num semaphores: 750

// SemaphoreId seems to be (id | (something << 12));
typedef s32 SemaphoreId;

struct Thread;

struct Semaphore
{
   //! List of threads waiting on this semaphore, ordered by priority.
   ThreadQueue waitThreadQueue;

   //! Unknown list of threads.
   Thread * unknown0x04;

   //! Unique semaphore identifier.
   SemaphoreId id;

   //! Process this semaphore belongs to.
   ProcessId pid;

   //! Current semaphore signal count.
   s32 count;

   //! Maximum semaphore signal count.
   s32 maxCount;

   //! Previous free semaphore, linked list.
   s16 prevFreeSemaphoreIndex;

   //! Next free semaphore, linked list.
   s16 nextFreeSemaphoreIndex;
};

Error
IOS_CreateSemaphore(s32 maxCount,
                    s32 initialCount);

Error
IOS_DestroySempahore(SemaphoreId id);

Error
IOS_WaitSemaphore(SemaphoreId id,
                  BOOL tryWait);

Error
IOS_SignalSempahore(SemaphoreId id);
