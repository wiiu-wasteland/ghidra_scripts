#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>
#include <ios/kernel/threadqueue.h>

#define MaxNumMessageQueues 750

struct Thread;

typedef s32 MessageQueueId;
typedef u32 Message;

struct MessageQueue
{
   ThreadQueue receiveQueue;
   ThreadQueue sendQueue;
   u32 used;
   u32 first;
   u32 size;
   Message * messages;
   s32 uid;
   u8 pid;
   MessageQueueFlags flags;
   u16 unk0x1E;
};

Error
IOS_CreateMessageQueue(Message * messageBuffer,
                       u32 numMessages);

Error
IOS_DestroyMessageQueue(MessageQueueId id);

Error
IOS_SendMessage(MessageQueueId id,
                Message message,
                MessageFlags flags);

Error
IOS_JamMessage(MessageQueueId id,
               Message message,
               MessageFlags flags);

Error
IOS_ReceiveMessage(MessageQueueId id,
                   Message * message,
                   MessageFlags flags);
