#pragma once
#include "ios_kernel_enum.h"
#include "ios/ios_error.h"

#include <cstdint>
#include <libcpu/be2_struct.h>

Error
IOS_ReadOTP(OtpFieldIndex fieldIndex,
            u32 * buffer,
            u32 bufferSize);
