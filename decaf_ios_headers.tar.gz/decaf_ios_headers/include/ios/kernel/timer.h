#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>
#include <ios/kernel/messagequeue.h>

#pragma pack(push, 1)

#define MaxNumTimers            256
#define MaxNumTimersPerProcess  64

typedef s32 TimerId;
typedef u64 TimerTicks;
typedef u32 TimeMicroseconds32;
typedef u64 TimeMicroseconds64;

struct Timer
{
   TimerId uid;
   TimerState state;
   TimerTicks nextTriggerTime;
   TimeMicroseconds32 period;
   MessageQueueId queueId;
   Message message;
   ProcessId processId;

   //! This timers index in the TimerManager timers list.
   s16 index;

   //! If state == Free this is the index of the next free timer.
   //! If state == Running this is the index of the next running timer.
   s16 nextTimerIdx;

   //! If state == Free this is the index of the previous free timer.
   //! If state == Running this is the index of the previous running timer.
   s16 prevTimerIdx;

   u16 unk0x26;
};

struct TimerManager
{
   //! Total number of timers that have been created.
   u32 totalCreatedTimers;

   //! Number of timers each process has
   u16 numProcessTimers[NumIosProcess];

   //! Index of the first running Timer, ordered by nextTriggerTime.
   s16 firstRunningTimerIdx;

   //! Index of the last running Timer, ordered by nextTriggerTime.
   s16 lastRunningTimerIdx;

   //! Number of actively running timers.
   u16 numRunningTimers;

   //! Index of the first free Timer.
   s16 firstFreeIdx;

   //! Index of the last free Timer.
   s16 lastFreeIdx;

   //! Number of registered Timers.
   u16 numRegistered;

   //! Highest number of registered Timers at one time.
   u16 mostRegistered;

   u16 unk0x2E;

   Timer timers[MaxNumTimers];
};

#pragma pack(pop)

Error
IOS_GetUpTime64(TimerTicks* outTime);

Error
IOS_CreateTimer(u32 delay,
                u32 period,
                MessageQueueId queue,
                Message message);

Error
IOS_DestroyTimer(TimerId timerId);

Error
IOS_StopTimer(TimerId timerId);

Error
IOS_RestartTimer(TimerId timerId,
                 u32 delay,
                 u32 period);
