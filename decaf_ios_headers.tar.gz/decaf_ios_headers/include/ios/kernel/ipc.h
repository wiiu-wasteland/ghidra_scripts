#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/ios_ipc.h>
#include <ios/kernel/enum.h>
#include <ios/kernel/resourcemanager.h>


Error
IOS_Open(char * device,
         OpenMode mode);

Error
IOS_OpenAsync(char * device,
              OpenMode mode,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Close(ResourceHandleId handle);

Error
IOS_CloseAsync(ResourceHandleId handle,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Read(ResourceHandleId handle,
         void * buffer,
         u32 length);

Error
IOS_ReadAsync(ResourceHandleId handle,
              void * buffer,
              u32 length,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Write(ResourceHandleId handle,
          void * buffer,
          u32 length);

Error
IOS_WriteAsync(ResourceHandleId handle,
               void * buffer,
               u32 length,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Seek(ResourceHandleId handle,
         u32 offset,
         u32 origin);

Error
IOS_SeekAsync(ResourceHandleId handle,
              u32 offset,
              u32 origin,
              MessageQueueId asyncNotifyQueue,
              IpcRequest * asyncNotifyRequest);

Error
IOS_Ioctl(ResourceHandleId handle,
          u32 ioctlRequest,
          void * inputBuffer,
          u32 inputBufferLength,
          void * outputBuffer,
          u32 outputBufferLength);

Error
IOS_IoctlAsync(ResourceHandleId handle,
               u32 ioctlRequest,
               void * inputBuffer,
               u32 inputBufferLength,
               void * outputBuffer,
               u32 outputBufferLength,
               MessageQueueId asyncNotifyQueue,
               IpcRequest * asyncNotifyRequest);

Error
IOS_Ioctlv(ResourceHandleId handle,
           u32 ioctlRequest,
           u32 numVecIn,
           u32 numVecOut,
           IoctlVec * vecs);

Error
IOS_IoctlvAsync(ResourceHandleId handle,
                u32 request,
                u32 numVecIn,
                u32 numVecOut,
                IoctlVec * vecs,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);

Error
IOS_Resume(ResourceHandleId handle,
           u32 unkArg0,
           u32 unkArg1);

Error
IOS_ResumeAsync(ResourceHandleId handle,
                u32 unkArg0,
                u32 unkArg1,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);

Error
IOS_Suspend(ResourceHandleId handle,
            u32 unkArg0,
            u32 unkArg1);

Error
IOS_SuspendAsync(ResourceHandleId handle,
                 u32 unkArg0,
                 u32 unkArg1,
                 MessageQueueId asyncNotifyQueue,
                 IpcRequest * asyncNotifyRequest);

Error
IOS_SvcMsg(ResourceHandleId handle,
           u32 command,
           u32 unkArg1,
           u32 unkArg2,
           u32 unkArg3);

Error
IOS_SvcMsgAsync(ResourceHandleId handle,
                u32 command,
                u32 unkArg1,
                u32 unkArg2,
                u32 unkArg3,
                MessageQueueId asyncNotifyQueue,
                IpcRequest * asyncNotifyRequest);
