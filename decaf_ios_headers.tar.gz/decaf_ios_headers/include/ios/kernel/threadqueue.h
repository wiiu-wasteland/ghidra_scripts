#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

struct Thread;

struct ThreadQueue
{
   //! Linked list on thread->threadQueueNext.
   Thread * first;
};
