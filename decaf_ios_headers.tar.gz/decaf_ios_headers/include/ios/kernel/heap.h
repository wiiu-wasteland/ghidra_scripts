#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

typedef s32 HeapId;

#define SharedHeapId        1
#define LocalProcessHeapId  0xCAFE
#define CrossProcessHeapId  0xCAFF

struct Heap
{
   void * base;
   ProcessId pid;
   u32 size;
   struct HeapBlock * firstFreeBlock;
   u32 errorCountAllocOutOfMemory;
   u32 errorCountFreeBlockNotInHeap;
   u32 errorCountExpandInvalidBlock;
   u32 errorCountCorruptedBlock;
   HeapFlags flags;
   u32 currentAllocatedSize;
   u32 largestAllocatedSize;
   u32 totalAllocCount;
   u32 totalFreeCount;
   u32 errorCountFreeUnallocatedBlock;
   u32 errorCountAllocInvalidHeap;
   HeapId id;
};

struct HeapBlock
{
   HeapBlockState state;
   u32 size;
   HeapBlock * prev;
   HeapBlock * next;
};

Error
IOS_CreateHeap(void * ptr,
               u32 size);

Error
IOS_CreateLocalProcessHeap(void * ptr,
                           u32 size);

Error
IOS_CreateCrossProcessHeap(u32 size);

Error
IOS_DestroyHeap(HeapId id);

void *
IOS_HeapAlloc(HeapId id,
              u32 size);

void *
IOS_HeapAllocAligned(HeapId id,
                     u32 size,
                     u32 alignment);

void *
IOS_HeapRealloc(HeapId id,
                void * ptr,
                u32 size);

Error
IOS_HeapFree(HeapId id,
             void * ptr);

Error
IOS_HeapFreeAndZero(HeapId id,
                    void * ptr);
