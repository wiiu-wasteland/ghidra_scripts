#pragma once
#include <ios/types.h>
#include <ios/ios_enum.h>
#include <ios/kernel/enum.h>

#define MaxNumThreads 180
#define MaxThreadPriority 127

#pragma pack(push, 1)

typedef u32 ThreadId;
typedef s32 ThreadPriority;
typedef Error(*ThreadEntryFn)(void *);

#define CurrentThread 0

struct ThreadContext
{
   u32 cpsr;
   u32 gpr[14];
   u32 lr;
   u32 pc;
};

struct ThreadLocalStorage
{
    u32 storage[9];
};

struct Thread
{
   ThreadContext context;

   //! Link to next item in the thread queue.
   Thread * threadQueueNext;

   ThreadPriority maxPriority;
   ThreadPriority priority;
   ThreadState state;
   ProcessId pid;
   ThreadId id;
   ThreadFlags flags;
   Error exitValue;

   //! Queue of threads waiting to join this thread.
   ThreadQueue joinQueue;

   //! The thread queue this therad is currently in.
   ThreadQueue * threadQueue;

   char unknown0[0x38];
   void * stackPointer;
   char unknown1[0x8];
   void * sysStackAddr;
   void * userStackAddr;
   u32 userStackSize;
   ThreadLocalStorage * threadLocalStorage;
   u32 profileCount;
   u32 profileTime;
};

#pragma pack(pop)

Error
IOS_CreateThread(ThreadEntryFn entry,
                 void * context,
                 u8 * stackTop,
                 u32 stackSize,
                 int priority,
                 ThreadFlags flags);

Error
IOS_JoinThread(ThreadId id,
               Error * returnedValue);

Error
IOS_CancelThread(ThreadId id,
                 Error exitValue);

Error
IOS_StartThread(ThreadId id);

Error
IOS_SuspendThread(ThreadId id);

Error
IOS_YieldCurrentThread();

Error
IOS_GetCurrentThreadId();

ThreadLocalStorage *
IOS_GetCurrentThreadLocalStorage();

Error
IOS_GetThreadPriority(ThreadId id);

Error
IOS_SetThreadPriority(ThreadId id,
                      ThreadPriority priority);
