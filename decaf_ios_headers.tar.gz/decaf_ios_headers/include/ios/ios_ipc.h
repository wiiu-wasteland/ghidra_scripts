#pragma once
#include <ios/ios_enum.h>
#include <ios/types.h>

#pragma pack(push, 1)

typedef u32 GroupId;
typedef s32 Handle;
typedef u64 TitleId;

#define IoctlVecAlign 0x40

/**
 * Structure used for ioctlv arguments.
 */
struct IoctlVec
{
   //! Virtual address of buffer.
   void * vaddr;

   //! Length of buffer.
   u32 len;

   //! Physical address of buffer.
   void * paddr;
};

struct IpcRequestArgsOpen
{
   char * name;
   u32 nameLen;
   OpenMode mode;
   u64 caps;
};

struct IpcRequestArgsClose
{
   u32 unkArg0;
};

struct IpcRequestArgsRead
{
   void * data;
   u32 length;
};

struct IpcRequestArgsWrite
{
   void * data;
   u32 length;
};

struct IpcRequestArgsSeek
{
   u32 offset;
   SeekOrigin origin;
};

struct IpcRequestArgsIoctl
{
   u32 request;
   void * inputBuffer;
   u32 inputLength;
   void * outputBuffer;
   u32 outputLength;
};

struct IpcRequestArgsIoctlv
{
   u32 request;
   u32 numVecIn;
   u32 numVecOut;
   IoctlVec * vecs;
};

struct IpcRequestArgsResume
{
   u32 unkArg0;
   u32 unkArg1;
};

struct IpcRequestArgsSuspend
{
   u32 unkArg0;
   u32 unkArg1;
};

struct IpcRequestArgsSvcMsg
{
   u32 command;
   u32 unkArg1;
   u32 unkArg2;
   u32 unkArg3;
};

struct IpcRequestArgs
{
   union
   {
      IpcRequestArgsOpen open;
      IpcRequestArgsClose close;
      IpcRequestArgsRead read;
      IpcRequestArgsWrite write;
      IpcRequestArgsSeek seek;
      IpcRequestArgsIoctl ioctl;
      IpcRequestArgsIoctlv ioctlv;
      IpcRequestArgsResume resume;
      IpcRequestArgsSuspend suspend;
      IpcRequestArgsSvcMsg svcMsg;
      u32 args[5];
   };
};

/**
 * The actual data which is sent as an IPC request between IOSU (ARM) and
 * PowerPC cores.
 */
struct IpcRequest
{
   #define ArgCount 5

   //! IOS command to execute
   Command command;

   //! IPC command result
   Error reply;

   //! Handle for the IOS resource
   Handle handle;

   //! Flags, always 0
   u32 flags;

   //! CPU the request originated from
   CpuId cpuId;

   union
   {
      //! Cafe/PowerPC process ID the request originated from, only valid when
      //! receiving the request in the kernel ipc thread.
      s32 clientPid;

      //! IOS ProcessId the request originated from, this is the value that
      //! should be used everywhere except from the kernel ipc thread.
      ProcessId processId;
   };

   //! Title ID the request originated from
   TitleId titleId;

   //! Group ID
   GroupId groupId;

   //! IPC command args
   IpcRequestArgs args;
};

#pragma pack(pop)
